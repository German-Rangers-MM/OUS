// Bestätigung per GUI
private _result = false;
_result = ["Soll die Mission gestartet werden?", "Confirm", true, true] call BIS_fnc_guiMessage;

// keine Bestätigung -> Vorgang abbrechen
if (!_result) exitWith {};

// get values from config
private _einleitung = getMissionConfigValue "einleitung";
private _auftrag = getMissionConfigValue "auftrag";
private _titleOrtEinheit = getMissionConfigValue "titleOrtEinheit";
private _titleMissionsname = getMissionConfigValue "titleMissionsname";
private _tickerCountry = getMissionConfigValue "tickerCountry";
private _tickerLocation = getMissionConfigValue "tickerLocation";

missionstarted = true;
publicVariable "missionstarted";

// get intro-type from config, defaults to "PR"
private _intro = getMissionConfigValue ["intro", "pr"];

private _intropfad = "scripts\core\MCC_sequence_intro" + _intro + ".sqf";

private _line1 = format ["<t color='#ffffff' size='2'>%1</t>",_einleitung];
private _line2 = format ["<t color='#ffffff' size='2'>%1</t>",_auftrag];
private _line3 = format ["<t color='#ffffff' size='1'>%1<br/>____________________</t><br/><t color='#ffffff' size='5'>%2</t><br/><br/><img image='images\GermanRangersLogo.paa' shadow='0' size='8'/><img image='images\JTF-OUS_Insignia_512px.paa' shadow='0' size='8'/>",_titleOrtEinheit,_titleMissionsname];

private _time = floor((count _tickerCountry + count _tickerLocation) * 0.4);	// Zeit berechnen, die der Ticker ungefähr braucht

[[_line1, _line2, _line3, _tickerCountry, _tickerLocation, _time], _intropfad] remoteExec ["execVM",[0, -2] select isDedicated];
//"scripts\MCC_sequence_startteleport.sqf" remoteExec ["execVM"];