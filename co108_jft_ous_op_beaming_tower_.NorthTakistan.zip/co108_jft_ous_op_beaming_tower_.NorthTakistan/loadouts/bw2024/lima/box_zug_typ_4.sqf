[
    "Zug Typ 4 - Panzerbrechend",
    "GerRng_faction_Box_A_Zug_IV",

    //ACE
    ["ACE_20Rnd_762x51_M993_AP_Mag",10],

    //SPS
    ["SPS_HKG3PMAG_30Rnd_556x45_B_M995",30],
    ["SPS_HKG3PMAG_30Rnd_556x45_B_Mk318",20],

    ["SPS_20Rnd_762x51mm_M80A1_EPR",10],
    ["SPS_20Rnd_762x51mm_M80A1_EPR_Tracer",5]
];
