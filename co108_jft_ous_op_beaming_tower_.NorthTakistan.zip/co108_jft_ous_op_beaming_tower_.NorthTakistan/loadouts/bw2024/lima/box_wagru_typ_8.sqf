[
    "WaGru Typ 8 - Combat Engineering",
    "GerRng_faction_Box_WS_WaGru_VIII",

    //ACE
    ["ACE_Clacker", 2],
    ["ACE_Fortify", 4],
    ["ACE_EntrenchingTool", 6],
    ["ace_marker_flags_black", 10],
    ["ace_marker_flags_blue", 10],
    ["ace_marker_flags_green", 10],
    ["ace_marker_flags_red", 10],
    ["ACE_SpraypaintBlack", 2],
    ["ACE_SpraypaintBlue", 2],
    ["ACE_SpraypaintGreen", 2],
    ["ACE_SpraypaintRed", 2],
    ["ACE_wirecutter", 6],

    //ARMA 3
    ["DemoCharge_Remote_Mag", 2],
    ["SatchelCharge_Remote_Mag", 2],

    //CUP
    ["CUP_launch_BF3", 2],

    //TSP
    ["tsp_breach_block_mag", 2],
    ["tsp_breach_package_mag", 2],
    ["tsp_breach_stick_mag", 5]
];
