[
    // ------------------------------------------------------------------
    // ------------------------------------------------------------------
    // Waffen
    // ------------------------------------------------------------------
    // ------------------------------------------------------------------

    "CUP_smg_MP5A5",
    "SMG_05_F",
    "CUP_smg_MP7",

    // ------------------------------------------------------------------
    // ------------------------------------------------------------------
    // Visiere
    // ------------------------------------------------------------------
    // ------------------------------------------------------------------
    
    // ------------------------------------------------------------------
    // ------------------------------------------------------------------
    // Pointer
    // ------------------------------------------------------------------
    // ------------------------------------------------------------------
    
    // ------------------------------------------------------------------
    // ------------------------------------------------------------------
    // Bipods
    // ------------------------------------------------------------------
    // ------------------------------------------------------------------
    
    // ------------------------------------------------------------------
    // ------------------------------------------------------------------
    // Secondarys
    // ------------------------------------------------------------------
    // ------------------------------------------------------------------
    
    // ------------------------------------------------------------------
    // ------------------------------------------------------------------
    // Launcher
    // ------------------------------------------------------------------
    // ------------------------------------------------------------------

    "kat_CarryStretcherBag",

    // ------------------------------------------------------------------
    // ------------------------------------------------------------------
    // uniforms
    // ------------------------------------------------------------------
    // ------------------------------------------------------------------

    "U_B_CBRN_Suit_01_Wdl_F",

    // ------------------------------------------------------------------
    // ------------------------------------------------------------------
    // vests
    // ------------------------------------------------------------------
    // ------------------------------------------------------------------

    "CUP_V_B_GER_Pvest_Fleck_Med",
    "CUP_V_B_GER_Pvest_Trop_Med",

    "CUP_V_B_GER_Pvest_Fleck_OFC",
    "CUP_V_B_GER_Pvest_Trop_OFC",

    "CUP_V_B_GER_Pvest_Fleck_Med_LT",
    "CUP_V_B_GER_Pvest_Trop_Med_LT",

    "CUP_V_B_GER_Tactical_Fleck",

    "CUP_V_B_GER_Armatus_Trop",
    "CUP_V_B_GER_Armatus_BB_Trop",

    "CUP_V_B_GER_Armatus_Fleck",
    "CUP_V_B_GER_Armatus_BB_Fleck",

    "CUP_V_B_Armatus_Black",
    "CUP_V_B_Armatus_BB_Black",

    // ------------------------------------------------------------------
    // ------------------------------------------------------------------
    // backpacks
    // ------------------------------------------------------------------
    // ------------------------------------------------------------------

    "TFAR_mr3000_bwmod",
    "TFAR_rt1523g_big_bwmod_tropen",
    "TFAR_rt1523g_bwmod",
    "TFAR_rt1523g_rhs",
    
    "tfw_ilbeMR3000_blade_flk",
    "tfw_ilbeMR3000_blade_trp",
    "tfw_ilbeRT1523_blade_flk",
    "tfw_ilbeRT1523_blade_trp",
    
    "tfw_ilbeMR3000_blade_avdflk",
    "tfw_ilbeMR3000_blade_avdtrp",
    "tfw_ilbeRT1523_blade_avdflk",
    "tfw_ilbeRT1523_blade_avdtrp",
    
    "tfw_ilbeMR3000_DD_flk",
    "tfw_ilbeMR3000_DD_trp",
    "tfw_ilbeRT1523_DD_flk",
    "tfw_ilbeRT1523_DD_trp",
    
    "tfw_ilbeMR3000_DD_avdflk",
    "tfw_ilbeMR3000_DD_avdtrp",
    "tfw_ilbeRT1523_DD_avdflk",
    "tfw_ilbeRT1523_DD_avdtrp",
    
    "tfw_ilbeMR3000_whip_flk",
    "tfw_ilbeMR3000_whip_trp",
    "tfw_ilbeRT1523_whip_flk",
    "tfw_ilbeRT1523_whip_trp",
    
    "tfw_ilbeMR3000_whip_avdflk",
    "tfw_ilbeMR3000_whip_avdtrp",
    "tfw_ilbeRT1523_whip_avdflk",
    "tfw_ilbeRT1523_whip_avdtrp",
    
    "tfw_ilbeRT1523_blade_gr",
    "tfw_ilbeMR3000_blade_gr",
    "tfw_ilbeRT1523_blade_coy",
    "tfw_ilbeMR3000_blade_coy",
    
    "tfw_ilbeRT1523_DD_gr",
    "tfw_ilbeMR3000_DD_gr",
    "tfw_ilbeRT1523_DD_coy",
    "tfw_ilbeMR3000_DD_coy",
    
    "tfw_ilbeRT1523_whip_gr",
    "tfw_ilbeMR3000_whip_gr",
    "tfw_ilbeRT1523_whip_coy",
    "tfw_ilbeMR3000_whip_coy",
    
    "B_SCBA_01_F",
    "B_CombinationUnitRespirator_01_F",

    // ------------------------------------------------------------------
    // ------------------------------------------------------------------
    // Helme
    // ------------------------------------------------------------------
    // ------------------------------------------------------------------

    "CUP_H_Ger_Boonie_Flecktarn",
    "CUP_H_Ger_Boonie_desert",
    "CUP_H_Ger_Boonie2_Flecktarn",
    "CUP_H_Ger_Boonie2_desert",

    "CUP_H_Ger_Cap_EP_Grn1",
    "CUP_H_Ger_Cap_EP_tan1",
    
    "GerRng_helmets_helmet_pilot_w",
    "GerRng_helmets_helmet_pilot_b",

    // ------------------------------------------------------------------
    // ------------------------------------------------------------------
    // goggles
    // ------------------------------------------------------------------
    // ------------------------------------------------------------------
    
    "G_Aviator",
    "G_Bandanna_aviator",
    "G_Bandanna_blk",
    "CUP_G_TK_roundGlasses",
    "G_AirPurifyingRespirator_01_F",
    "G_RegulatorMask_F",

    "CUP_G_PMC_RadioHeadset_Glasses_Dark",
    "CUP_G_PMC_RadioHeadset_Glasses_Ember",
    "CUP_G_PMC_RadioHeadset_Glasses",
    "CUP_G_PMC_RadioHeadset",

    // ------------------------------------------------------------------
    // ------------------------------------------------------------------
    // NVGs
    // ------------------------------------------------------------------
    // ------------------------------------------------------------------

    "CUP_NVG_GPNVG_black",
    "CUP_NVG_GPNVG_black_WP",

    // ------------------------------------------------------------------
    // ------------------------------------------------------------------
    // binoculars
    // ------------------------------------------------------------------
    // ------------------------------------------------------------------

    "Rangefinder",

    "Laserdesignator_02_ghex_F",

    "ACE_Vector",

    "GerRng_utils_Laserdesignator_khk",
    "GerRng_utils_Laserdesignator_olv",
    "GerRng_utils_Laserdesignator_snd",

    // ------------------------------------------------------------------
    // ------------------------------------------------------------------
    // items
    // ------------------------------------------------------------------
    // ------------------------------------------------------------------

    "Itemandroid",
    "ItemcTab",
    "ItemMicroDAGR",
    "ItemGPS",

    "KAT_Katmin",
    "KAT_STS",
    "KAT_Ranger",
    "KAT_Cavmin",

    "ChemicalDetector_01_watch_F",
    "KAT_ChemicalDetector",
    
    "tfw_blade",
    "tfw_dd",
    "tfw_whip",

    // ------------------------------------------------------------------
    // ------------------------------------------------------------------
    // magazines
    // ------------------------------------------------------------------
    // ------------------------------------------------------------------

    "CUP_20Rnd_46x30_MP7",
    "CUP_40Rnd_46x30_MP7",
    "CUP_40Rnd_46x30_MP7_Red_Tracer",
    "CUP_30Rnd_9x19_MP5",

    // ------------------------------------------------------------------
    // ------------------------------------------------------------------
    // Grenades / throw
    // ------------------------------------------------------------------
    // ------------------------------------------------------------------

    "miniGrenade",

    "B_IR_Grenade",

    "ACE_HandFlare_Red",
    "ACE_HandFlare_Green",

    // ------------------------------------------------------------------
    // ------------------------------------------------------------------
    // explosives / Put
    // ------------------------------------------------------------------
    // ------------------------------------------------------------------
    
    // ------------------------------------------------------------------
    // ------------------------------------------------------------------
    // Medical
    // ------------------------------------------------------------------
    // ------------------------------------------------------------------

    "ACE_adenosine",
    "ACE_bodyBag",
    "ACE_epinephrine",
    "ACE_salineIV",
    "ACE_surgicalKit",

    "kat_IV_16",
    "kat_accuvac",
    "kat_X_AED",
    "kat_amiodarone",
    "kat_Carbonate",
    "kat_atropine",
    "kat_AED",
    "kat_BVM",
    "kat_Caffeine",
    "kat_EACA",
    "kat_IO_FAST",
    "kat_fentanyl",
    "kat_ketamine",
    "kat_larynx",
    "kat_naloxone",
    "kat_nitroglycerin",
    "kat_Painkiller",
    "kat_Penthrox",
    "kat_pocketBVM",
    "kat_oxygentank_150",
    "kat_oxygentank_300",
    "kat_Pulseoximeter",
    "kat_TXA",
    "ACE_personalAidKit",
    "kat_lorazepam",
    "kat_phenylephrine",
    "kat_stethoscope",
    "kat_ncdKit",
    
    "GerRng_kat_changes_glucometerSet",
    "GerRng_kat_changes_GSCI",

    // ------------------------------------------------------------------
    // ------------------------------------------------------------------
    // Misc 1
    // ------------------------------------------------------------------
    // ------------------------------------------------------------------

    "toolKit",

    "ACE_artilleryTable",
    "ACE_ATragMX",
    "ACE_DefusalKit",
    "ACE_fortify",
    "ACE_HuntIR_monitor",
    "ACE_Kestrel4500",
    "ACE_Clacker",
    "ACE_PlottingBoard",
    "ACE_RangeCard",
    "ACE_SpottingScope",
    "ACE_Tripod",

    "kat_CarryStretcherBag",

    "tfw_rf3080Item",

    // ------------------------------------------------------------------
    // ------------------------------------------------------------------
    // Misc 2
    // ------------------------------------------------------------------
    // ------------------------------------------------------------------

    "ace_marker_flags_black",
    "ace_marker_flags_blue",
    "ace_marker_flags_orange",
    "ace_marker_flags_purple",
    "ace_marker_flags_red",
    "ace_marker_flags_white",
    "ace_marker_flags_yellow",
    "ace_marker_flags_green", 

    "ace_flags_black",
    "ace_flags_blue",
    "ace_flags_green",
    "ace_flags_orange",
    "ace_flags_purple",
    "ace_flags_red",
    "ace_flags_white",
    "ace_flags_yellow",

    "ACE_rope12",
    "ACE_rope15",
    "ACE_rope15",
    "ACE_rope18",
    "ACE_rope27",
    "ACE_rope36",

    "ACE_SpareBarrel",

    "ACE_SpraypaintBlack",
    "ACE_SpraypaintBlue",
    "ACE_Spraypaintgreen",
    "ACE_SpraypaintRed",
    "ACE_SpraypaintWhite",
    "ACE_SpraypaintYellow",

    "GerRng_bandoliers_grenade_3_3_flare_hand",

    "ACE_UAVBattery",

    "kat_gasmaskFilter",
    "kat_sealant"
    
];
