[
    // ------------------------------------------------------------------
    // ------------------------------------------------------------------
    // Waffen
    // ------------------------------------------------------------------
    // ------------------------------------------------------------------

    "CUP_arifle_AG36",
    "CUP_arifle_G36A_AG36_RIS_camo",
    "CUP_arifle_G36A_AG36_RIS_wdl",

    "CUP_arifle_G36A3_AG36",
    "CUP_arifle_G36A3_AG36_camo",
    "CUP_arifle_G36A3_AG36_wdl",

    "CUP_arifle_HK416_CQB_AG36",
    "CUP_arifle_HK416_CQB_AG36_Desert",
    "CUP_arifle_HK416_CQB_AG36_Wood",

    "CUP_arifle_HK416_AGL_Black",
    "CUP_arifle_HK416_AGL_Desert",
    "CUP_arifle_HK416_AGL_Wood",

    "CUP_arifle_HK417_12_AG36",
    "CUP_arifle_HK417_12_AG36_Desert",
    "CUP_arifle_HK417_12_AG36_Wood",

    "arifle_SPAR_03_blk_F",
    "arifle_SPAR_03_snd_F",
    "arifle_SPAR_03_khk_F",

    "CUP_smg_MP5A5",
    "SMG_05_F",
    "CUP_smg_MP7",

    //SPS

    "SPS_hk416_14_5_glm_hk_black_f",
    "SPS_hk416_14_5_glm_hk_sf_black_f",
    "SPS_hk416_14_5_glm_hk_a7_black_f",
    "SPS_hk416_14_5_glm_hk_ctr_black_f",
    "SPS_hk416_14_5_glm_hk_ctr_sf_black_f",
    "SPS_hk416_14_5_glm_hk_ctr_a7_black_f",
    "SPS_hk416_16_5_glm_hk_black_f",
    "SPS_hk416_16_5_glm_hk_sf_black_f",
    "SPS_hk416_16_5_glm_hk_a7_black_f",
    "SPS_hk416_16_5_glm_hk_ctr_black_f",
    "SPS_hk416_16_5_glm_hk_ctr_sf_black_f",
    "SPS_hk416_16_5_glm_hk_ctr_a7_black_f",

    "SPS_hk416_14_5_glm_hk_ral8000_f",
    "SPS_hk416_14_5_glm_hk_sf_ral8000_f",
    "SPS_hk416_14_5_glm_hk_a7_ral8000_f",
    "SPS_hk416_14_5_glm_hk_ctr_ral8000_f",
    "SPS_hk416_14_5_glm_hk_ctr_sf_ral8000_f",
    "SPS_hk416_14_5_glm_hk_ctr_a7_ral8000_f",
    "SPS_hk416_16_5_glm_hk_ral8000_f",
    "SPS_hk416_16_5_glm_hk_sf_ral8000_f",
    "SPS_hk416_16_5_glm_hk_a7_ral8000_f",
    "SPS_hk416_16_5_glm_hk_ctr_ral8000_f",
    "SPS_hk416_16_5_glm_hk_ctr_sf_ral8000_f",
    "SPS_hk416_16_5_glm_hk_ctr_a7_ral8000_f",

    "SPS_hk416_20_black_f",
    "SPS_hk416_20_hk_sf_black_f",
    "SPS_hk416_20_hk_a7_black_f",
    "SPS_hk416_20_vfg_black_f",
    "SPS_hk416_20_hk_vfg_sf_black_f",
    "SPS_hk416_20_hk_vfg_a7_black_f",
    "SPS_hk416_20_afg_black_f",
    "SPS_hk416_20_hk_afg_sf_black_f",
    "SPS_hk416_20_hk_afg_a7_black_f",
    "SPS_hk416_20_hk_ctr_black_f",
    "SPS_hk416_20_hk_ctr_sf_black_f",
    "SPS_hk416_20_hk_ctr_a7_black_f",
    "SPS_hk416_20_hk_ctr_vfg_black_f",
    "SPS_hk416_20_hk_ctr_vfg_sf_black_f",
    "SPS_hk416_20_hk_ctr_vfg_a7_black_f",
    "SPS_hk416_20_hk_ctr_afg_black_f",
    "SPS_hk416_20_hk_ctr_afg_sf_black_f",
    "SPS_hk416_20_hk_ctr_afg_a7_black_f",

    "SPS_hk416_20_g95_black_f",
    "SPS_hk416_20_g95_hk_sf_black_f",
    "SPS_hk416_20_g95_hk_a7_black_f",
    "SPS_hk416_20_g95_vfg_black_f",
    "SPS_hk416_20_g95_hk_vfg_sf_black_f",
    "SPS_hk416_20_g95_hk_vfg_a7_black_f",
    "SPS_hk416_20_g95_afg_black_f",
    "SPS_hk416_20_g95_hk_afg_sf_black_f",
    "SPS_hk416_20_g95_hk_afg_a7_black_f",
    "SPS_hk416_20_g95_hk_ctr_black_f",
    "SPS_hk416_20_g95_hk_ctr_sf_black_f",
    "SPS_hk416_20_g95_hk_ctr_a7_black_f",
    "SPS_hk416_20_g95_hk_ctr_vfg_black_f",
    "SPS_hk416_20_g95_hk_ctr_vfg_sf_black_f",
    "SPS_hk416_20_g95_hk_ctr_vfg_a7_black_f",
    "SPS_hk416_20_g95_hk_ctr_afg_black_f",
    "SPS_hk416_20_g95_hk_ctr_afg_sf_black_f",
    "SPS_hk416_20_g95_hk_ctr_afg_a7_black_f",

    "SPS_hk416_20_exsmr_black_f",
    "SPS_hk416_20_exsmr_hk_sf_black_f",
    "SPS_hk416_20_exsmr_hk_a7_black_f",
    "SPS_hk416_20_exsmr_vfg_black_f",
    "SPS_hk416_20_exsmr_hk_vfg_sf_black_f",
    "SPS_hk416_20_exsmr_hk_vfg_a7_black_f",
    "SPS_hk416_20_exsmr_afg_black_f",
    "SPS_hk416_20_exsmr_hk_afg_sf_black_f",
    "SPS_hk416_20_exsmr_hk_afg_a7_black_f",
    "SPS_hk416_20_exsmr_hk_ctr_black_f",
    "SPS_hk416_20_exsmr_hk_ctr_sf_black_f",
    "SPS_hk416_20_exsmr_hk_ctr_a7_black_f",
    "SPS_hk416_20_exsmr_hk_ctr_vfg_black_f",
    "SPS_hk416_20_exsmr_hk_ctr_vfg_sf_black_f",
    "SPS_hk416_20_exsmr_hk_ctr_vfg_a7_black_f",
    "SPS_hk416_20_exsmr_hk_ctr_afg_black_f",
    "SPS_hk416_20_exsmr_hk_ctr_afg_sf_black_f",
    "SPS_hk416_20_exsmr_hk_ctr_afg_a7_black_f",

    "SPS_hk416_20_exsl_black_f",
    "SPS_hk416_20_exsl_hk_sf_black_f",
    "SPS_hk416_20_exsl_hk_a7_black_f",
    "SPS_hk416_20_exsl_vfg_black_f",
    "SPS_hk416_20_exsl_hk_vfg_sf_black_f",
    "SPS_hk416_20_exsl_hk_vfg_a7_black_f",
    "SPS_hk416_20_exsl_afg_black_f",
    "SPS_hk416_20_exsl_hk_afg_sf_black_f",
    "SPS_hk416_20_exsl_hk_afg_a7_black_f",
    "SPS_hk416_20_exsl_hk_ctr_black_f",
    "SPS_hk416_20_exsl_hk_ctr_sf_black_f",
    "SPS_hk416_20_exsl_hk_ctr_a7_black_f",
    "SPS_hk416_20_exsl_hk_ctr_vfg_black_f",
    "SPS_hk416_20_exsl_hk_ctr_vfg_sf_black_f",
    "SPS_hk416_20_exsl_hk_ctr_vfg_a7_black_f",
    "SPS_hk416_20_exsl_hk_ctr_afg_black_f",
    "SPS_hk416_20_exsl_hk_ctr_afg_sf_black_f",
    "SPS_hk416_20_exsl_hk_ctr_afg_a7_black_f",

    "SPS_hk417_20_vfg_black_f",
    "SPS_hk417_20_afg_black_f",
    "SPS_hk417_20_vfg_ral8000_f",
    "SPS_hk417_20_afg_ral8000_f",
    "SPS_hk417_20_vfg_fde_f",
    "SPS_hk417_20_afg_fde_f",

    "SPS_hk416_20_ral8000_f",
    "SPS_hk416_20_hk_sf_ral8000_f",
    "SPS_hk416_20_hk_a7_ral8000_f",
    "SPS_hk416_20_vfg_ral8000_f",
    "SPS_hk416_20_hk_vfg_sf_ral8000_f",
    "SPS_hk416_20_hk_vfg_a7_ral8000_f",
    "SPS_hk416_20_afg_ral8000_f",
    "SPS_hk416_20_hk_afg_sf_ral8000_f",
    "SPS_hk416_20_hk_afg_a7_ral8000_f",
    "SPS_hk416_20_hk_ctr_ral8000_f",
    "SPS_hk416_20_hk_ctr_sf_ral8000_f",
    "SPS_hk416_20_hk_ctr_a7_ral8000_f",
    "SPS_hk416_20_hk_ctr_vfg_ral8000_f",
    "SPS_hk416_20_hk_ctr_vfg_sf_ral8000_f",
    "SPS_hk416_20_hk_ctr_vfg_a7_ral8000_f",
    "SPS_hk416_20_hk_ctr_afg_ral8000_f",
    "SPS_hk416_20_hk_ctr_afg_sf_ral8000_f",
    "SPS_hk416_20_hk_ctr_afg_a7_ral8000_f",

    "SPS_hk416_20_g95_ral8000_f",
    "SPS_hk416_20_g95_hk_sf_ral8000_f",
    "SPS_hk416_20_g95_hk_a7_ral8000_f",
    "SPS_hk416_20_g95_vfg_ral8000_f",
    "SPS_hk416_20_g95_hk_vfg_sf_ral8000_f",
    "SPS_hk416_20_g95_hk_vfg_a7_ral8000_f",
    "SPS_hk416_20_g95_afg_ral8000_f",
    "SPS_hk416_20_g95_hk_afg_sf_ral8000_f",
    "SPS_hk416_20_g95_hk_afg_a7_ral8000_f",
    "SPS_hk416_20_g95_hk_ctr_ral8000_f",
    "SPS_hk416_20_g95_hk_ctr_sf_ral8000_f",
    "SPS_hk416_20_g95_hk_ctr_a7_ral8000_f",
    "SPS_hk416_20_g95_hk_ctr_vfg_ral8000_f",
    "SPS_hk416_20_g95_hk_ctr_vfg_sf_ral8000_f",
    "SPS_hk416_20_g95_hk_ctr_vfg_a7_ral8000_f",
    "SPS_hk416_20_g95_hk_ctr_afg_ral8000_f",
    "SPS_hk416_20_g95_hk_ctr_afg_sf_ral8000_f",
    "SPS_hk416_20_g95_hk_ctr_afg_a7_ral8000_f",

    "SPS_hk416_20_exsmr_ral8000_f",
    "SPS_hk416_20_exsmr_hk_sf_ral8000_f",
    "SPS_hk416_20_exsmr_hk_a7_ral8000_f",
    "SPS_hk416_20_exsmr_vfg_ral8000_f",
    "SPS_hk416_20_exsmr_hk_vfg_sf_ral8000_f",
    "SPS_hk416_20_exsmr_hk_vfg_a7_ral8000_f",
    "SPS_hk416_20_exsmr_afg_ral8000_f",
    "SPS_hk416_20_exsmr_hk_afg_sf_ral8000_f",
    "SPS_hk416_20_exsmr_hk_afg_a7_ral8000_f",
    "SPS_hk416_20_exsmr_hk_ctr_ral8000_f",
    "SPS_hk416_20_exsmr_hk_ctr_sf_ral8000_f",
    "SPS_hk416_20_exsmr_hk_ctr_a7_ral8000_f",
    "SPS_hk416_20_exsmr_hk_ctr_vfg_ral8000_f",
    "SPS_hk416_20_exsmr_hk_ctr_vfg_sf_ral8000_f",
    "SPS_hk416_20_exsmr_hk_ctr_vfg_a7_ral8000_f",
    "SPS_hk416_20_exsmr_hk_ctr_afg_ral8000_f",
    "SPS_hk416_20_exsmr_hk_ctr_afg_sf_ral8000_f",
    "SPS_hk416_20_exsmr_hk_ctr_afg_a7_ral8000_f",

    "SPS_hk416_20_exsl_ral8000_f",
    "SPS_hk416_20_exsl_hk_sf_ral8000_f",
    "SPS_hk416_20_exsl_hk_a7_ral8000_f",
    "SPS_hk416_20_exsl_vfg_ral8000_f",
    "SPS_hk416_20_exsl_hk_vfg_sf_ral8000_f",
    "SPS_hk416_20_exsl_hk_vfg_a7_ral8000_f",
    "SPS_hk416_20_exsl_afg_ral8000_f",
    "SPS_hk416_20_exsl_hk_afg_sf_ral8000_f",
    "SPS_hk416_20_exsl_hk_afg_a7_ral8000_f",
    "SPS_hk416_20_exsl_hk_ctr_ral8000_f",
    "SPS_hk416_20_exsl_hk_ctr_sf_ral8000_f",
    "SPS_hk416_20_exsl_hk_ctr_a7_ral8000_f",
    "SPS_hk416_20_exsl_hk_ctr_vfg_ral8000_f",
    "SPS_hk416_20_exsl_hk_ctr_vfg_sf_ral8000_f",
    "SPS_hk416_20_exsl_hk_ctr_vfg_a7_ral8000_f",
    "SPS_hk416_20_exsl_hk_ctr_afg_ral8000_f",
    "SPS_hk416_20_exsl_hk_ctr_afg_sf_ral8000_f",
    "SPS_hk416_20_exsl_hk_ctr_afg_a7_ral8000_f",

    // ------------------------------------------------------------------
    // ------------------------------------------------------------------
    // Visiere
    // ------------------------------------------------------------------
    // ------------------------------------------------------------------

    "CUP_optic_AC11704_Black",
    "CUP_optic_AC11704_tan",
    "CUP_optic_AC11704_OD",

    "CUP_optic_Elcan_SpecterDR_RMR_black",
    "CUP_optic_Elcan_SpecterDR_RMR",
    "CUP_optic_Elcan_SpecterDR_RMR_od",
    "CUP_optic_Elcan_SpecterDR_KF_RMR_black",
    "CUP_optic_Elcan_SpecterDR_KF_RMR",
    "CUP_optic_Elcan_SpecterDR_KF_RMR_od",

    "CUP_optic_Elcan_reflex",
    "CUP_optic_Elcan_reflex_Coyote",
    "CUP_optic_Elcan_reflex_OD",

    "optic_Holosight_blk_F",
    "optic_Holosight",
    "optic_Holosight_lush_F",

    "optic_Holosight_smg_blk_F",
    "optic_Holosight_smg",
    "optic_Holosight_smg_khk_F",

    "CUP_optic_HensoldtZO_low",
    "CUP_optic_HensoldtZO_low_desert",
    "CUP_optic_HensoldtZO_low_od",

    "CUP_optic_HensoldtZO_low_RDS",
    "CUP_optic_HensoldtZO_low_RDS_desert",
    "CUP_optic_HensoldtZO_low_RDS_od",

    "CUP_optic_ZeissZPoint",
    "CUP_optic_ZeissZPoint_desert",
    "CUP_optic_ZeissZPoint_wood",

    "optic_AMS",
    "optic_AMS_snd",
    "optic_AMS_khk",

    "ACE_optic_Hamr_2D",

    //SPS

    "SPS_Optic_SnB_HP_1_8_Black_PVS24LR",
    "SPS_Optic_SnB_HP_1_8_FDE_PVS24LR",
    "SPS_Optic_SnB_HP_1_8_RAL8000_PVS24LR",

    "SPS_Optic_SnB_HP_1_8_Black",
    "SPS_Optic_SnB_HP_1_8_FDE",
    "SPS_Optic_SnB_HP_1_8_RAL8000",

    "SPS_EOTech_Vudu_Black_PVS24LR",
    "SPS_EOTech_Vudu_Tan_PVS24LR",

    "SPS_EOTech_Vudu_Black",
    "SPS_EOTech_Vudu_Tan",

    "sps_aimpoint_T1_Black",
    "sps_aimpoint_T1_Black50",
    "sps_aimpoint_T1_Sand",
    "sps_aimpoint_T1_Sand50",

    "sps_aimpoint_T1_3xMAG_up_Black",
    "sps_aimpoint_T1_3xMAG_up",

    "sps_aimpoint_T1_Black_High",
    "sps_aimpoint_T1_Black_High50",
    "sps_aimpoint_T1_High",
    "sps_aimpoint_T1_High50",

    "SPS_EOTech_Black",
    "SPS_EOTech_Black50",
    "SPS_EOTech_Tan",
    "SPS_EOTech_Tan50",

    "SPS_EOTech_Black_3xMAG_up",
    "SPS_EOTech_Tan_3xMAG_up",
    "SPS_EOTech_Black_5xMAG_up",
    "SPS_EOTech_Tan_5xMAG_up",

    // ------------------------------------------------------------------
    // ------------------------------------------------------------------
    // Pointer
    // ------------------------------------------------------------------
    // ------------------------------------------------------------------

    "acc_flashlight_pistol",
    "CUP_acc_Glock17_Flashlight",

    // ------------------------------------------------------------------
    // ------------------------------------------------------------------
    // Muzzle
    // ------------------------------------------------------------------
    // ------------------------------------------------------------------
    
    "muzzle_antenna_02_f",
    "muzzle_antenna_03_f",
    "muzzle_antenna_01_f",
    
    // ------------------------------------------------------------------
    // ------------------------------------------------------------------
    // Bipods
    // ------------------------------------------------------------------
    // ------------------------------------------------------------------
    
    // ------------------------------------------------------------------
    // ------------------------------------------------------------------
    // Secondarys
    // ------------------------------------------------------------------
    // ------------------------------------------------------------------

    "ACE_Flashlight_Maglite_ML300L",

    "CUP_hgun_FlareGun",

    "hgun_esd_01_F",

    "ACE_VMH3",
    "ACE_VMM3",

    "CUP_hgun_Glock17",
    "CUP_hgun_Glock17_blk",
    "CUP_hgun_Glock17_tan",

    // ------------------------------------------------------------------
    // ------------------------------------------------------------------
    // Launcher
    // ------------------------------------------------------------------
    // ------------------------------------------------------------------


    "GerRng_utils_remote_designator_d",
    "GerRng_utils_remote_designator_w",

    "kat_CarryStretcherBag",

    // ------------------------------------------------------------------
    // ------------------------------------------------------------------
    // uniforms
    // ------------------------------------------------------------------
    // ------------------------------------------------------------------

    "CUP_U_B_GER_Fleck_Overalls_pilot",

    "CUP_U_B_GER_Fleck_Overalls_tank",

    "U_B_HeliPilotCoveralls",

    "CUP_U_B_USArmy_pilotoverall",
    "CUP_U_B_USMC_pilotoverall",

    // ------------------------------------------------------------------
    // ------------------------------------------------------------------
    // vests
    // ------------------------------------------------------------------
    // ------------------------------------------------------------------

    "CUP_V_B_GER_Pvest_Fleck_Gren",
    "CUP_V_B_GER_Pvest_Trop_Gren",

    "CUP_V_B_GER_Pvest_Fleck_MG",
    "CUP_V_B_GER_Pvest_Trop_MG",

    "CUP_V_B_GER_Pvest_Fleck_Med",
    "CUP_V_B_GER_Pvest_Trop_Med",

    "CUP_V_B_GER_Pvest_Fleck_OFC",
    "CUP_V_B_GER_Pvest_Trop_OFC",

    "CUP_V_B_GER_Pvest_Fleck_RFL",
    "CUP_V_B_GER_Pvest_Trop_RFL",

    "CUP_V_B_GER_Pvest_Fleck_TL",
    "CUP_V_B_GER_Pvest_Trop_TL",

    "CUP_V_B_GER_Pvest_Fleck_Gren_LT",
    "CUP_V_B_GER_Pvest_Trop_Gren_LT",

    "CUP_V_B_GER_Pvest_Fleck_MG_LT",
    "CUP_V_B_GER_Pvest_Trop_MG_LT",

    "CUP_V_B_GER_Pvest_Fleck_Med_LT",
    "CUP_V_B_GER_Pvest_Trop_Med_LT",

    "CUP_V_B_GER_Pvest_Fleck_RFL_LT",
    "CUP_V_B_GER_Pvest_Trop_RFL_LT",

    "CUP_V_B_GER_Pvest_Fleck_TL_LT",
    "CUP_V_B_GER_Pvest_Trop_TL_LT",

    "CUP_V_B_GER_Carrier_vest_3",

    "CUP_V_B_pilotvest",
    "Aircrew_vest_2_NH",

    "V_PlateCarrierIAGL_oli",

    "CUP_V_B_Armatus_Black",
    "CUP_V_B_Armatus_BB_Black",

    "CUP_V_B_JPC_Fleck_Light",
    "CUP_V_B_JPC_Trop_Light",

    "CUP_V_B_LBT_LBV_Black",

    "CUP_V_B_GER_Carrier_Vest",
    "CUP_V_B_GER_Carrier_Vest_2",

    // ------------------------------------------------------------------
    // ------------------------------------------------------------------
    // backpacks
    // ------------------------------------------------------------------
    // ------------------------------------------------------------------

    "TFAR_mr3000_bwmod",
    "TFAR_rt1523g_big_bwmod_tropen",
    "TFAR_rt1523g_bwmod",
    "TFAR_rt1523g_rhs",

    "CUP_B_M252_Bipod_Bag",
    "CUP_B_M252_Gun_Bag",
    
    "tfw_ilbeMR3000_blade_flk",
    "tfw_ilbeMR3000_blade_trp",
    "tfw_ilbeRT1523_blade_flk",
    "tfw_ilbeRT1523_blade_trp",
    
    "tfw_ilbeMR3000_DD_flk",
    "tfw_ilbeMR3000_DD_trp",
    "tfw_ilbeRT1523_DD_flk",
    "tfw_ilbeRT1523_DD_trp",
    
    "tfw_ilbeMR3000_whip_flk",
    "tfw_ilbeMR3000_whip_trp",
    "tfw_ilbeRT1523_whip_flk",
    "tfw_ilbeRT1523_whip_trp",
    
    "tfw_ilbeRT1523_blade_gr",
    "tfw_ilbeMR3000_blade_gr",
    "tfw_ilbeRT1523_blade_coy",
    "tfw_ilbeMR3000_blade_coy",
    
    "tfw_ilbeRT1523_DD_gr",
    "tfw_ilbeMR3000_DD_gr",
    "tfw_ilbeRT1523_DD_coy",
    "tfw_ilbeMR3000_DD_coy",
    
    "tfw_ilbeRT1523_whip_gr",
    "tfw_ilbeMR3000_whip_gr",
    "tfw_ilbeRT1523_whip_coy",
    "tfw_ilbeMR3000_whip_coy",
    
    "tfw_ilbeMR3000_whip_romeoflk",
    "tfw_ilbeRT1523_whip_romeoflk",
    "tfw_ilbeARC210_whip_romeoflk",
    "tfw_ilbeMR3000_DD_romeoflk",
    "tfw_ilbeRT1523_DD_romeoflk",
    "tfw_ilbeARC210_DD_romeoflk",
    "tfw_ilbeMR3000_blade_romeoflk",
    "tfw_ilbeRT1523_blade_romeoflk",
    "tfw_ilbeARC210_blade_romeoflk",

    "tfw_ilbeMR3000_whip_romeotrp",
    "tfw_ilbeRT1523_whip_romeotrp",
    "tfw_ilbeARC210_whip_romeotrp",
    "tfw_ilbeMR3000_DD_romeotrp",
    "tfw_ilbeRT1523_DD_romeotrp",
    "tfw_ilbeARC210_DD_romeotrp",
    "tfw_ilbeMR3000_blade_romeotrp",
    "tfw_ilbeRT1523_blade_romeotrp",
    "tfw_ilbeARC210_blade_romeotrp",

    
    "tfw_ilbeARC210_blade_coy",
    "tfw_ilbeARC210_DD_coy",
    "tfw_ilbeARC210_whipext_coy",
    "tfw_ilbeARC210_whip_coy",

    // ------------------------------------------------------------------
    // ------------------------------------------------------------------
    // Helme
    // ------------------------------------------------------------------
    // ------------------------------------------------------------------

    "CUP_H_Ger_Boonie2_Flecktarn",
    "CUP_H_Ger_Boonie2_desert",

    "CUP_H_Ger_Cap_EP_Grn1",
    "CUP_H_Ger_Cap_EP_tan1",
    "CUP_H_Ger_Cap_Grn2",

    "H_pilotHelmetFighter_B",

    "H_crewHelmetHeli_O",

    "H_pilotHelmetHeli_O",

    "H_Helmetcrew_B",
    "H_crewHelmetHeli_B",

    "H_pilotHelmetHeli_B",

    "H_HelmetSpecB_wdl",
    "H_HelmetSpecB_sand",

    "CUP_H_SPH4_khaki",

    "GerRng_helmets_helmet_pilot_w",
    "GerRng_helmets_helmet_pilot_b",

    // ------------------------------------------------------------------
    // ------------------------------------------------------------------
    // goggles
    // ------------------------------------------------------------------
    // ------------------------------------------------------------------

    "G_Aviator",

    "G_Balaclava_blk",

    "G_Bandanna_aviator",
    "G_Bandanna_beast",

    "G_AirPurifyingRespirator_01_F",

    "G_RegulatorMask_F",

    "CUP_G_PMC_RadioHeadset_Glasses_Dark",
    "CUP_G_PMC_RadioHeadset_Glasses_Ember",
    "CUP_G_PMC_RadioHeadset_Glasses",
    "CUP_G_PMC_RadioHeadset",

    // ------------------------------------------------------------------
    // ------------------------------------------------------------------
    // NVGs
    // ------------------------------------------------------------------
    // ------------------------------------------------------------------

    "CUP_NVG_GPNVG_black",
    "CUP_NVG_GPNVG_black_WP",

    // ------------------------------------------------------------------
    // ------------------------------------------------------------------
    // binoculars
    // ------------------------------------------------------------------
    // ------------------------------------------------------------------

    "Rangefinder",

    "ACE_Vector",

    "GerRng_utils_Laserdesignator_khk",
    "GerRng_utils_Laserdesignator_olv",
    "GerRng_utils_Laserdesignator_snd",

    // ------------------------------------------------------------------
    // ------------------------------------------------------------------
    // items
    // ------------------------------------------------------------------
    // ------------------------------------------------------------------

    "Itemandroid",
    "ItemcTab",
    "ItemMicroDAGR",

    "ItemGPS",

    "B_UavTerminal",

    "C_UavTerminal",
    
    "ChemicalDetector_01_watch_F",

    "KAT_ChemicalDetector",
    
    "tfw_blade",
    "tfw_dd",
    "tfw_whip",

    // ------------------------------------------------------------------
    // ------------------------------------------------------------------
    // magazines
    // ------------------------------------------------------------------
    // ------------------------------------------------------------------

    "CUP_30Rnd_9x19_MP5",
    "CUP_40Rnd_46x30_MP7",

    "CUP_1Rnd_HE_M203",
    "CUP_1Rnd_HEDP_M203",

    "CUP_1Rnd_StarCluster_Red_M203",

    "Laserbatteries",

    "UGL_FlareGreen_F",
    "UGL_FlareCIR_F",
    "UGL_FlareRed_F",
    "UGL_FlareWhite_F",
    "UGL_FlareYellow_F",

    "UGL_FlareGreen_Illumination_F",
    "UGL_FlareRed_Illumination_F",
    "UGL_FlareWhite_Illumination_F",
    "UGL_FlareYellow_Illumination_F",

    "ACE_40mm_Flare_white",
    "ACE_40mm_Flare_green",
    "ACE_40mm_Flare_red",

    "1Rnd_SmokeBlue_Grenade_shell",
    "1Rnd_SmokeGreen_Grenade_shell",
    "1Rnd_SmokeOrange_Grenade_shell",
    "1Rnd_SmokePurple_Grenade_shell",
    "1Rnd_SmokeRed_Grenade_shell",
    "1Rnd_Smoke_Grenade_shell",
    "1Rnd_SmokeYellow_Grenade_shell",

    "ACE_1Rnd_82mm_Mo_HE",
    "ACE_1Rnd_82mm_Mo_Illum",
    "ACE_1Rnd_82mm_Mo_Smoke",
    "ACE_1Rnd_82mm_Mo_HE_LaserGuided",

    // ------------------------------------------------------------------
    // ------------------------------------------------------------------
    // Grenades / throw
    // ------------------------------------------------------------------
    // ------------------------------------------------------------------

    "Chemlight_blue",
    "Chemlight_green",
    "ACE_Chemlight_HiBlue",
    "ACE_Chemlight_HiGreen",
    "ACE_Chemlight_HiRed",
    "ACE_Chemlight_HiWhite",
    "ACE_Chemlight_HiYellow",
    "ACE_Chemlight_IR",
    "ACE_Chemlight_Orange",
    "Chemlight_red",
    "ACE_Chemlight_UltraHiOrange",
    "ACE_Chemlight_White",
    "Chemlight_yellow",

    "B_IR_Grenade",

    "ACE_HandFlare_Green",
    "ACE_HandFlare_Red",
    "ACE_HandFlare_White",
    "ACE_HandFlare_Yellow",

    "SmokeShellBlue",
    "SmokeShellGreen",
    "SmokeShellOrange",
    "SmokeShellPurple",
    "SmokeShellRed",
    "SmokeShellYellow",
    "SmokeShell",

    // ------------------------------------------------------------------
    // ------------------------------------------------------------------
    // explosives / Put
    // ------------------------------------------------------------------
    // ------------------------------------------------------------------

    "DemoCharge_Remote_Mag",
    "SatchelCharge_Remote_Mag",

    // ------------------------------------------------------------------
    // ------------------------------------------------------------------
    // Medical
    // ------------------------------------------------------------------
    // ------------------------------------------------------------------

    "ACE_adenosine",
    "ACE_bodyBag",
    "ACE_epinephrine",
    "ACE_salineIV",
    "ACE_surgicalKit",

    "kat_IV_16",
    "kat_accuvac",
    "kat_X_AED",
    "kat_amiodarone",
    "kat_Carbonate",
    "kat_atropine",
    "kat_AED",
    "kat_BVM",
    "kat_Caffeine",
    "kat_EACA",
    "kat_IO_FAST",
    "kat_fentanyl",
    "kat_ketamine",
    "kat_larynx",
    "kat_naloxone",
    "kat_nitroglycerin",
    "kat_Painkiller",
    "kat_Penthrox",
    "kat_pocketBVM",
    "kat_oxygentank_150",
    "kat_oxygentank_300",
    "kat_Pulseoximeter",
    "kat_TXA",
    "kat_stethoscope",
    "kat_ncdKit",

    // ------------------------------------------------------------------
    // ------------------------------------------------------------------
    // Misc 1
    // ------------------------------------------------------------------
    // ------------------------------------------------------------------

    "ACE_artilleryTable",
    "ACE_ATragMX",
    "ACE_DAGR",
    "ACE_DefusalKit",
    "ACE_Fortify",
    "ACE_HuntIR_monitor",
    "ACE_Kestrel4500",

    "ACE_M26_Clacker",
    "ACE_Clacker",

    "ACE_microDAGR",
    "acex_intelitems_notepad",
    "ACE_PlottingBoard",
    "ACE_RangeCard",

    "tfw_rf3080Item",

    "tsp_breach_shock",

    "ToolKit",
    "tfw_blade",
    "tfw_whip",
    "tfw_dd",

    // ------------------------------------------------------------------
    // ------------------------------------------------------------------
    // Misc 2
    // ------------------------------------------------------------------
    // ------------------------------------------------------------------

    "kat_helistretcher",

    "ACE_CableTie",
    "ACE_IR_Strobe_Item",

    "ace_flags_black",
    "ace_flags_blue",
    "ace_flags_green",
    "ace_flags_orange",
    "ace_flags_purple",
    "ace_flags_red",
    "ace_flags_white",
    "ace_flags_yellow",

    "kat_gasmaskFilter",
    "kat_sealant",

    "ItemcTabHCam",

    "crowsew_tfar_icom",
    "crowsew_ctrack",

    "ace_marker_flags_black",
    "ace_marker_flags_blue",
    "ace_marker_flags_green",
    "ace_marker_flags_orange",
    "ace_marker_flags_purple",
    "ace_marker_flags_red",
    "ace_marker_flags_white",
    "ace_marker_flags_yellow",

    "ACE_rope12",
    "ACE_rope15",
    "ACE_rope18",
    "ACE_rope27",
    "ACE_rope3",
    "ACE_rope36",
    "ACE_rope6",

    "ACE_SpraypaintBlack",
    "ACE_SpraypaintBlue",
    "ACE_SpraypaintGreen",
    "ACE_SpraypaintRed",
    "ACE_SpraypaintWhite",
    "ACE_SpraypaintYellow",

    "itc_land_tablet_rover",

    "GerRng_bandoliers_grenade_8_8_exp_40mm",
    "GerRng_bandoliers_grenade_8_8_flare_40mm",
    "GerRng_bandoliers_grenade_8_8_smoke_40mm",
    "GerRng_bandoliers_grenade_3_3_flare_hand",
    "GerRng_bandoliers_rifle_5_5_417_30Rnd"

];
