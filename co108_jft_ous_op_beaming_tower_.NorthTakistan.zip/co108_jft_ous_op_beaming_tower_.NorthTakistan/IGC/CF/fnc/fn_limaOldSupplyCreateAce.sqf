params ["_object"];


//------------------------------------------------------------------
//------------------------------------------------------------------
//
//						LIMA Supply Point
//
//------------------------------------------------------------------
//------------------------------------------------------------------
		
// Icon für Boxen-deploy
_icon = "a3\ui_f\data\igui\cfg\cursors\iconboardin_ca.paa";
_iconEod = "a3\ui_f\data\igui\cfg\simpletasks\types\mine_ca.paa";
_iconCBRN = "z\ace\addons\medical_gui\data\categories\airway_management.paa";
_iconWaGru = "a3\ui_f\data\gui\rsc\rscdisplayarsenal\secondaryweapon_ca.paa";
_iconWaGruStatic = "a3\ui_f\data\map\vehicleicons\iconcrategrenades_ca.paa";
_iconZug = "a3\ui_f\data\gui\rsc\rscdisplayarsenal\cargomagall_ca.paa";
_iconErsatz = "a3\ui_f\data\igui\cfg\actions\repair_ca.paa";
_iconSan = "a3\ui_f\data\igui\cfg\simpletasks\types\heal_ca.paa";
_iconBodybags = "z\ace\addons\medical_gui\ui\grave.paa";
_iconSierra = "a3\weapons_f\data\ui\icon_sniper_ca.paa";
_iconVerpflegung ="z\ace\addons\field_rations\ui\icon_hud_hungerstatus.paa";


// Lima Supply Point Static & Mobile
{
    // Parent Action für Zug Boxen
    _zugBoxen = ["Zug Boxen","Zug Boxen",_iconZug,{ },{true}] call ace_interact_menu_fnc_createAction;
    [_x, 0, ["ACE_MainActions"], _zugBoxen] call ace_interact_menu_fnc_addActionToObject;
        //------------------------------------------------------------------
        _zug1 = ["Zug1","Zug Typ 1 - Standard 5.56",_icon,{params ["_object"]; [_object,"box_zug_typ_1"] call IGC_CF_fnc_limaOldSupplySpawnCrate},{true}] call ace_interact_menu_fnc_createAction;
        [_x, 0, ["ACE_MainActions", "Zug Boxen"], _zug1] call ace_interact_menu_fnc_addActionToObject;

        _zug2 = ["Zug2","Zug Typ 2 - Standard 7.62",_icon,{params ["_object"]; [_object,"box_zug_typ_2"] call IGC_CF_fnc_limaOldSupplySpawnCrate},{true}] call ace_interact_menu_fnc_createAction;
        [_x, 0, ["ACE_MainActions", "Zug Boxen"], _zug2] call ace_interact_menu_fnc_addActionToObject;

        _zug3 = ["Zug3","Zug Typ 3 - LMG-Munnition",_icon,{params ["_object"]; [_object,"box_zug_typ_3"] call IGC_CF_fnc_limaOldSupplySpawnCrate},{true}] call ace_interact_menu_fnc_createAction;
        [_x, 0, ["ACE_MainActions", "Zug Boxen"], _zug3] call ace_interact_menu_fnc_addActionToObject;

        _zug4 = ["Zug4","Zug Typ 4 - Panzerbrechend",_icon,{params ["_object"]; [_object,"box_zug_typ_4"] call IGC_CF_fnc_limaOldSupplySpawnCrate},{true}] call ace_interact_menu_fnc_createAction;
        [_x, 0, ["ACE_MainActions", "Zug Boxen"], _zug4] call ace_interact_menu_fnc_addActionToObject;

        _zug5 = ["Zug5","Zug Typ 5 - Unterlaufgranaten",_icon,{params ["_object"]; [_object,"box_zug_typ_5"] call IGC_CF_fnc_limaOldSupplySpawnCrate},{true}] call ace_interact_menu_fnc_createAction;
        [_x, 0, ["ACE_MainActions", "Zug Boxen"], _zug5] call ace_interact_menu_fnc_addActionToObject;

        _zug6 = ["Zug6","Zug Typ 6 - Granaten",_icon,{params ["_object"]; [_object,"box_zug_typ_6"] call IGC_CF_fnc_limaOldSupplySpawnCrate},{true}] call ace_interact_menu_fnc_createAction;
        [_x, 0, ["ACE_MainActions", "Zug Boxen"], _zug6] call ace_interact_menu_fnc_addActionToObject;

        _zug7 = ["Zug7","Zug Typ 7 - Sprengmittel",_icon,{params ["_object"]; [_object,"box_zug_typ_7"] call IGC_CF_fnc_limaOldSupplySpawnCrate},{true}] call ace_interact_menu_fnc_createAction;
        [_x, 0, ["ACE_MainActions", "Zug Boxen"], _zug7] call ace_interact_menu_fnc_addActionToObject;

        _zug8 = ["Zug8","Zug Typ 8 - Anti-Tank",_icon,{params ["_object"]; [_object,"box_zug_typ_8"] call IGC_CF_fnc_limaOldSupplySpawnCrate},{true}] call ace_interact_menu_fnc_createAction;
        [_x, 0, ["ACE_MainActions", "Zug Boxen"], _zug8] call ace_interact_menu_fnc_addActionToObject;

        _zug9 = ["Zug9","Zug Typ 9 - Ausrüstung",_icon,{params ["_object"]; [_object,"box_zug_typ_9"] call IGC_CF_fnc_limaOldSupplySpawnCrate},{true}] call ace_interact_menu_fnc_createAction;
        [_x, 0, ["ACE_MainActions", "Zug Boxen"], _zug9] call ace_interact_menu_fnc_addActionToObject;

        _zug10 = ["Zug10","Zug Typ 10 - Elektronik",_icon,{params ["_object"]; [_object,"box_zug_typ_10"] call IGC_CF_fnc_limaOldSupplySpawnCrate},{true}] call ace_interact_menu_fnc_createAction;
        [_x, 0, ["ACE_MainActions", "Zug Boxen"], _zug10] call ace_interact_menu_fnc_addActionToObject;

        _zug11 = ["Zug11","Zug Typ 11 - Munition HK417",_icon,{params ["_object"]; [_object,"box_zug_typ_11"] call IGC_CF_fnc_limaOldSupplySpawnCrate},{true}] call ace_interact_menu_fnc_createAction;
        [_x, 0, ["ACE_MainActions", "Zug Boxen"], _zug11] call ace_interact_menu_fnc_addActionToObject;

        //------------------------------------------------------------------
    // Parent Action für WaGru Boxen
    _waGruBoxen = ["WaGru Boxen","WaGru Boxen",_iconWaGru,{ },{true}] call ace_interact_menu_fnc_createAction;
    [_x, 0, ["ACE_MainActions"], _waGruBoxen] call ace_interact_menu_fnc_addActionToObject;
        //------------------------------------------------------------------
        _wagru1 = ["WaGru1","WaGru Typ 1 - MG3",_icon,{params ["_object"]; [_object,"box_wagru_typ_1"] call IGC_CF_fnc_limaOldSupplySpawnCrate},{true}] call ace_interact_menu_fnc_createAction;
        [_x, 0, ["ACE_MainActions", "WaGru Boxen"], _wagru1] call ace_interact_menu_fnc_addActionToObject;
                    
        _wagru2 = ["wagru2","WaGru Typ 2 - Mk48",_icon,{params ["_object"]; [_object,"box_wagru_typ_2"] call IGC_CF_fnc_limaOldSupplySpawnCrate},{true}] call ace_interact_menu_fnc_createAction;
        [_x, 0, ["ACE_MainActions", "WaGru Boxen"], _wagru2] call ace_interact_menu_fnc_addActionToObject;
                    
        _wagru3 = ["wagru3","WaGru Typ 3 - MAAWS",_icon,{params ["_object"]; [_object,"box_wagru_typ_3"] call IGC_CF_fnc_limaOldSupplySpawnCrate},{true}] call ace_interact_menu_fnc_createAction;
        [_x, 0, ["ACE_MainActions", "WaGru Boxen"], _wagru3] call ace_interact_menu_fnc_addActionToObject;
        
        _wagru8 = ["wagru8","WaGru Typ 8 - Combat Engineering",_icon,{params ["_object"]; [_object,"box_wagru_typ_8"] call IGC_CF_fnc_limaOldSupplySpawnCrate},{true}] call ace_interact_menu_fnc_createAction;
        [_x, 0, ["ACE_MainActions", "WaGru Boxen"], _wagru8] call ace_interact_menu_fnc_addActionToObject;

    
    
        //------------------------------------------------------------------
    // Parent Action für EOD Boxen
    _eodBoxen = ["EOD Boxen","EOD Boxen",_iconEod,{ },{true}] call ace_interact_menu_fnc_createAction;
    [_x, 0, ["ACE_MainActions"], _eodBoxen] call ace_interact_menu_fnc_addActionToObject;
        //------------------------------------------------------------------
        _eod1 = ["EOD1","EOD Typ I - Anzug",_icon,{params ["_object"]; [_object,"box_eod_typ_1"] call IGC_CF_fnc_limaOldSupplySpawnCrate},{true}] call ace_interact_menu_fnc_createAction;
        [_x, 0, ["ACE_MainActions","EOD Boxen"], _eod1] call ace_interact_menu_fnc_addActionToObject;	
    
        _eod2 = ["EOD2","EOD Typ II - Drohne",_icon,{params ["_object"]; [_object,"box_eod_typ_2"] call IGC_CF_fnc_limaOldSupplySpawnCrate},{true}] call ace_interact_menu_fnc_createAction;
        [_x, 0, ["ACE_MainActions","EOD Boxen"], _eod2] call ace_interact_menu_fnc_addActionToObject;	
    
        _eod3 = ["EOD3","EOD Typ III - Ausrüstung",_icon,{params ["_object"]; [_object,"box_eod_typ_3"] call IGC_CF_fnc_limaOldSupplySpawnCrate},{true}] call ace_interact_menu_fnc_createAction;
        [_x, 0, ["ACE_MainActions","EOD Boxen"], _eod3] call ace_interact_menu_fnc_addActionToObject;

        _eod4 = ["EOD4","EOD Typ IV - Zug",_icon,{params ["_object"]; [_object,"box_eod_typ_4"] call IGC_CF_fnc_limaOldSupplySpawnCrate},{true}] call ace_interact_menu_fnc_createAction;
        [_x, 0, ["ACE_MainActions","EOD Boxen"], _eod4] call ace_interact_menu_fnc_addActionToObject;
        //------------------------------------------------------------------
    // Parent Action für CBRN Boxen
    _cbrnBoxen = ["CBRN Boxen","CBRN Boxen",_iconCBRN,{ },{true}] call ace_interact_menu_fnc_createAction;
    [_x, 0, ["ACE_MainActions"], _cbrnBoxen] call ace_interact_menu_fnc_addActionToObject;
        //------------------------------------------------------------------
        _cbrn1 = ["CBRN1","Typ 1 - CBRN-Schutz",_icon,{params ["_object"]; [_object,"box_cbrn_typ_1"] call IGC_CF_fnc_limaOldSupplySpawnCrate},{true}] call ace_interact_menu_fnc_createAction;
        [_x, 0, ["ACE_MainActions", "CBRN Boxen"], _cbrn1] call ace_interact_menu_fnc_addActionToObject;

        _cbrn2 = ["CBRN2","Typ 2 - CBRN-Erkundung",_icon,{params ["_object"]; [_object,"box_cbrn_typ_2"] call IGC_CF_fnc_limaOldSupplySpawnCrate},{true}] call ace_interact_menu_fnc_createAction;
        [_x, 0, ["ACE_MainActions", "CBRN Boxen"], _cbrn2] call ace_interact_menu_fnc_addActionToObject;

        _cbrn3 = ["CBRN3","Typ 3 - CBRN-UGV",_icon,{params ["_object"]; [_object,"box_cbrn_typ_3"] call IGC_CF_fnc_limaOldSupplySpawnCrate},{true}] call ace_interact_menu_fnc_createAction;
        [_x, 0, ["ACE_MainActions", "CBRN Boxen"], _cbrn3] call ace_interact_menu_fnc_addActionToObject;
        //------------------------------------------------------------------
    // Parent Action für San Boxen
    _sanBoxen = ["San Boxen","San Boxen",_iconSan,{ },{true}] call ace_interact_menu_fnc_createAction;
    [_x, 0, ["ACE_MainActions"], _sanBoxen] call ace_interact_menu_fnc_addActionToObject;
        //------------------------------------------------------------------
        _san1 = ["San1","San Typ 1 - SanMat",_icon,{params ["_object"]; [_object,"box_san_typ_1"] call IGC_CF_fnc_limaOldSupplySpawnCrate},{true}] call ace_interact_menu_fnc_createAction;
        [_x, 0, ["ACE_MainActions", "San Boxen"], _san1] call ace_interact_menu_fnc_addActionToObject;	
    
        _san2 = ["San2","San Typ 2 - Leichensäcke",_iconBodybags,{params ["_object"]; [_object,"box_san_typ_2"] call IGC_CF_fnc_limaOldSupplySpawnCrate},{true}] call ace_interact_menu_fnc_createAction;
        [_x, 0, ["ACE_MainActions", "San Boxen"], _san2] call ace_interact_menu_fnc_addActionToObject;
        //------------------------------------------------------------------
    // Parent Action für Verpflegungs Boxen
    _vpflBoxen = ["Verpflegungs Boxen","Verpflegungs Boxen",_iconVerpflegung,{ },{true}] call ace_interact_menu_fnc_createAction;
    [_x, 0, ["ACE_MainActions"], _vpflBoxen] call ace_interact_menu_fnc_addActionToObject;
        //------------------------------------------------------------------
        _vpfl1 = ["Vpfl1","Verpflegung 1 - EPa Typ 1-4",_icon,{params ["_object"]; [_object,"box_vpfl_typ_1"] call IGC_CF_fnc_limaOldSupplySpawnCrate},{true}] call ace_interact_menu_fnc_createAction;
        [_x, 0, ["ACE_MainActions", "Verpflegungs Boxen"], _vpfl1] call ace_interact_menu_fnc_addActionToObject;  
    
        _vpfl2 = ["Vpfl2","Verpflegung 2 - EPa Typ 5-9",_icon,{params ["_object"]; [_object,"box_vpfl_typ_2"] call IGC_CF_fnc_limaOldSupplySpawnCrate},{true}] call ace_interact_menu_fnc_createAction;
        [_x, 0, ["ACE_MainActions", "Verpflegungs Boxen"], _vpfl2] call ace_interact_menu_fnc_addActionToObject;  

        _vpfl3 = ["Vpfl3","Verpflegung 3 - EPa Typ 10-14",_icon,{params ["_object"]; [_object,"box_vpfl_typ_3"] call IGC_CF_fnc_limaOldSupplySpawnCrate},{true}] call ace_interact_menu_fnc_createAction;
        [_x, 0, ["ACE_MainActions", "Verpflegungs Boxen"], _vpfl3] call ace_interact_menu_fnc_addActionToObject;  
    
        _vpfl4 = ["Vpfl4","Verpflegung 4 - EPa Typ 16-19",_icon,{params ["_object"]; [_object,"box_vpfl_typ_4"] call IGC_CF_fnc_limaOldSupplySpawnCrate},{true}] call ace_interact_menu_fnc_createAction;
        [_x, 0, ["ACE_MainActions", "Verpflegungs Boxen"], _vpfl4] call ace_interact_menu_fnc_addActionToObject;

        _vpfl5 = ["Vpfl6","Verpflegung 5 - Notration",_icon,{params ["_object"]; [_object,"box_vpfl_typ_5"] call IGC_CF_fnc_limaOldSupplySpawnCrate},{true}] call ace_interact_menu_fnc_createAction;
        [_x, 0, ["ACE_MainActions", "Verpflegungs Boxen"], _vpfl5] call ace_interact_menu_fnc_addActionToObject;  
        //------------------------------------------------------------------
    // Parent Action für Ersatzteile
    /*
    _ersatzteile = ["Ersatzteile","Ersatzteile",_iconErsatz,{ },{true}] call ace_interact_menu_fnc_createAction;
    [_x, 0, ["ACE_MainActions"], _ersatzteile] call ace_interact_menu_fnc_addActionToObject;
        //------------------------------------------------------------------
        _ersatzKette = ["ersatzKette","Ersatzkette",_icon,{params ["_object"]; [_object,"ersatzkette"] call IGC_CF_fnc_limaOldSupplySpawnCrate},{true}] call ace_interact_menu_fnc_createAction;
        [_x, 0, ["ACE_MainActions", "Ersatzteile"], _ersatzKette] call ace_interact_menu_fnc_addActionToObject;

        _ersatzRad = ["ersatzRad","Ersatzrad",_icon,{params ["_object"]; [_object,"ersatzrad"] call IGC_CF_fnc_limaOldSupplySpawnCrate},{true}] call ace_interact_menu_fnc_createAction;
        [_x, 0, ["ACE_MainActions", "Ersatzteile"], _ersatzRad] call ace_interact_menu_fnc_addActionToObject;
        //------------------------------------------------------------------
    */
    // Parent Action für Sierra
    _Sierra = ["Sierra","Sierra",_iconSierra,{ },{true}] call ace_interact_menu_fnc_createAction;
    [_x, 0, ["ACE_MainActions"], _Sierra] call ace_interact_menu_fnc_addActionToObject;
        //------------------------------------------------------------------
    _sierra1 = ["Sierra1","Sierra Typ 1 - Trupp 1 - S",_icon,{params ["_object"]; [_object,"box_sierra_typ_1"] call IGC_CF_fnc_limaOldSupplySpawnCrate},{true}] call ace_interact_menu_fnc_createAction;
    [_x, 0, ["ACE_MainActions", "Sierra"], _sierra1] call ace_interact_menu_fnc_addActionToObject;

    _sierra2 = ["Sierra2","Sierra Typ 2 - Trupp 1 - S",_icon,{params ["_object"]; [_object,"box_sierra_typ_2"] call IGC_CF_fnc_limaOldSupplySpawnCrate},{true}] call ace_interact_menu_fnc_createAction;
    [_x, 0, ["ACE_MainActions", "Sierra"], _sierra2] call ace_interact_menu_fnc_addActionToObject;

    _sierra3 = ["Sierra3","Sierra Typ 3 - Trupp 1 - A",_icon,{params ["_object"]; [_object,"box_sierra_typ_3"] call IGC_CF_fnc_limaOldSupplySpawnCrate},{true}] call ace_interact_menu_fnc_createAction;
    [_x, 0, ["ACE_MainActions", "Sierra"], _sierra3] call ace_interact_menu_fnc_addActionToObject;

    _sierra5 = ["Sierra5","Sierra Typ 5 - Trupp 2 - U",_icon,{params ["_object"]; [_object,"box_sierra_typ_5"] call IGC_CF_fnc_limaOldSupplySpawnCrate},{true}] call ace_interact_menu_fnc_createAction;
    [_x, 0, ["ACE_MainActions", "Sierra"], _sierra5] call ace_interact_menu_fnc_addActionToObject;

    _sierra6 = ["Sierra6","Sierra Typ 6 - Trupp 2 - U",_icon,{params ["_object"]; [_object,"box_sierra_typ_6"] call IGC_CF_fnc_limaOldSupplySpawnCrate},{true}] call ace_interact_menu_fnc_createAction;
    [_x, 0, ["ACE_MainActions", "Sierra"], _sierra6] call ace_interact_menu_fnc_addActionToObject;

    _sierra7 = ["Sierra7","Sierra Typ 7 - Trupp 2 - ST",_icon,{params ["_object"]; [_object,"box_sierra_typ_7"] call IGC_CF_fnc_limaOldSupplySpawnCrate},{true}] call ace_interact_menu_fnc_createAction;
    [_x, 0, ["ACE_MainActions", "Sierra"], _sierra7] call ace_interact_menu_fnc_addActionToObject;

    _sierra8 = ["Sierra8","Sierra Typ 8 - Munition",_icon,{params ["_object"]; [_object,"box_sierra_typ_8"] call IGC_CF_fnc_limaOldSupplySpawnCrate},{true}] call ace_interact_menu_fnc_createAction;
    [_x, 0, ["ACE_MainActions", "Sierra"], _sierra8] call ace_interact_menu_fnc_addActionToObject;

    _sierra9 = ["Sierra9","Sierra Typ 9 - Ausrüstung",_icon,{params ["_object"]; [_object,"box_sierra_typ_9"] call IGC_CF_fnc_limaOldSupplySpawnCrate},{true}] call ace_interact_menu_fnc_createAction;
    [_x, 0, ["ACE_MainActions", "Sierra"], _sierra9] call ace_interact_menu_fnc_addActionToObject;
    //------------------------------------------------------------------

    _supply = ["Supply","Transport Box (leer)",_icon,{params ["_object"]; [_object,"box_supply"] call IGC_CF_fnc_limaOldSupplySpawnCrate},{true}] call ace_interact_menu_fnc_createAction;
    [_x, 0, ["ACE_MainActions"], _supply] call ace_interact_menu_fnc_addActionToObject;


    
} forEach [_object];		
